package utils.interfaces;

import org.openqa.selenium.WebDriver;

public interface WebApplication {
	
	WebDriver getDriver();

}
