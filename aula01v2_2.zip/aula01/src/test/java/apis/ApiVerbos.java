package apis;

public interface ApiVerbos {

    void GET();

    void POST();

    void PUT();

    void PATCH();

    void DELETE();
}
