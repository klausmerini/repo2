package steps;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.pt.Dado;
import cucumber.api.java.pt.E;
import cucumber.api.java.pt.Entao;
import funcionalidades.CompraLivroFuncionalidade;
import pages.LoginHerokuPage;

public class CompraLivroSteps {
    private CompraLivroFuncionalidade compralivro;

    //    @Given("^que estou no site demowebshop$")
//    public void queEstouNoSiteDemowebshop()
//    {

    @Dado("^que estou no site demowebshop$")
    public void que_estou_no_site_demowebshop() throws Throwable {
        System.out.println("que_estou_no_site_demowebshop");
        this.compralivro = new CompraLivroFuncionalidade();
        compralivro.compraLivroAction();
    }

    @E("^clico em books$")
    public void clicoEmBooks() {
    }

    @Entao("^seleciono um livro$")
    public void selecionoUmLivro() throws InterruptedException {
        compralivro.selecionaLivroAction();
    }

    @Entao("^site adiciona o livro ao carrnho e compras$")
    public void siteAdicionaOLivroAoCarrnhoECompras() throws InterruptedException {
        compralivro.confirmaCompraAction();
    }


}