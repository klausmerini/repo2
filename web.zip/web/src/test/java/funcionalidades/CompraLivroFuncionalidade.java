package funcionalidades;

import pages.ComprarLivroPage;
import pages.LoginHerokuPage;
import utils.BaseTest;

public class CompraLivroFuncionalidade  extends BaseTest
{
    private ComprarLivroPage compraLivroPg;
    String urlSt;


    public void compraLivroAction() {
        this.webDriver.get("http://demowebshop.tricentis.com/");
        this.compraLivroPg = new ComprarLivroPage(webDriver);
        compraLivroPg.getSelecionaLivrosBtn().click();
    }

    public void selecionaLivroAction() throws InterruptedException
    {
        Thread.sleep(3000);
       compraLivroPg.getLivroBtn().click();

        Thread.sleep(10000);
    }


    public void confirmaCompraAction() throws InterruptedException
    {
        Thread.sleep(2000);
        compraLivroPg.getBarraResposta().click();

        Thread.sleep(5000);
        compraLivroPg.getLivroCompradoLink().click();

        Thread.sleep(5000);
    }
}
